-- SKYNETWORKS: ONE-TIME TASK SCHEMA ALIGNMENT
-- Based on the actual public.tasks columns shown in the Supabase screenshots.
-- Uses the existing canonical columns: area_name, lat, lng, currency.
-- Safe to run more than once. Does not delete tasks, accounts, messages or offers.

BEGIN;

-- Browser GPS is optional. A task with a town/neighbourhood but no GPS must still save.
ALTER TABLE public.tasks
  ALTER COLUMN lat DROP NOT NULL,
  ALTER COLUMN lng DROP NOT NULL;

-- Ensure new task rows receive the platform's currency even if another client omits it.
ALTER TABLE public.tasks
  ALTER COLUMN currency SET DEFAULT 'KES';

-- Keep the database contact-protection trigger compatible with all three table shapes.
-- JSON access avoids errors such as "record new has no field visibility" on tasks/offers.
CREATE OR REPLACE FUNCTION public.skynetworks_reject_public_contacts()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  row_data jsonb := to_jsonb(NEW);
  content text := '';
BEGIN
  IF TG_TABLE_NAME = 'messages' THEN
    IF COALESCE(row_data ->> 'visibility', 'public') <> 'public' THEN
      RETURN NEW;
    END IF;
    content := COALESCE(row_data ->> 'body', '');

  ELSIF TG_TABLE_NAME = 'tasks' THEN
    content := concat_ws(' ',
      row_data ->> 'title',
      row_data ->> 'description',
      row_data ->> 'area_name',
      row_data ->> 'location'
    );

  ELSIF TG_TABLE_NAME = 'offers' THEN
    content := COALESCE(row_data ->> 'message', '');

  ELSE
    RETURN NEW;
  END IF;

  IF content ~* '[A-Z0-9._%+-]+[[:space:]]*@[[:space:]]*[A-Z0-9.-]+[[:space:]]*\.[A-Z]{2,}'
     OR content ~* '(https?://|www\.)[^[:space:]]+'
     OR content ~* '(\+?[0-9][0-9 ()().-]{7,}[0-9])'
     OR content ~* '(whatsapp|telegram|t\.me|instagram|facebook|tiktok|snapchat|call me|text me|dm me|contact me|reach me|my number)'
     OR content ~* '[[:alnum:]-]+\.(com|net|org|co\.ke|io)(/[^[:space:]]*)?'
  THEN
    RAISE EXCEPTION
      'Contact details and personal links are not allowed in public marketplace content.'
      USING ERRCODE = '23514';
  END IF;

  RETURN NEW;
END;
$$;

NOTIFY pgrst, 'reload schema';

COMMIT;
